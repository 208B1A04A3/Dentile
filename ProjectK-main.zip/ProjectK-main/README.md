# ProjectK
# ✨  Dentile ✨

This is a web based application developed for health related based website in india

### This web based health application has been developed for the accomplishment of Future Ready Talent Internship program launched by Microsoft, Future Skills Prime, Quess, Github and EY.


**Project Link** -https://pramod4a3.github.io/ProjectK/#read
**project demo video link** - https://youtu.be/bMNAZHzBdks

## Azure technologies used for Project

- Static web apps
- Health bot

## Features and Functionalities 😃

- Interactive and responsive UI.
- Has many graphical and visual innovative effects.
- Have an aesthetically pleasing visual design and architecture.
- Has collection of many web pages including Home, About, Contact, Menu, health topics and health related information etc.
- User can know about health information through this website.
- Included the feedback Survey form to increase the scope of improvement
# Usages of Web application 
- Dental Bridge, Dental Implant, Dental Crowns, Teeth Whitening are extra facilities to be known what they choose they want.
- Creating The Healthy Smile You Want Through Science And Artistry.
- Caring Technologies For Your Dental Health.
- Dental Health Services

### About Us -


![Screenshot_20221201_222815](https://user-images.githubusercontent.com/110900111/205145829-964e30c9-8a83-48e9-b005-79480bb045e8.png)

### Services -


![Screenshot_20221201_223055](https://user-images.githubusercontent.com/110900111/205145728-49048837-3940-4cf1-a916-bb8124b16dcc.png)

### Contact -

![Screenshot_20221201_223200](https://user-images.githubusercontent.com/110900111/205145361-6483ae47-76d6-4f9c-a734-e9d162eaeba2.png)


### health bot



![Screenshot_20221201_221847](https://user-images.githubusercontent.com/110900111/205145863-9ef26c96-ac3d-4e15-8e6e-4a8fe79a520e.png)

## Tech Stack 💻

- [Azure(Hosting)](https://azure.microsoft.com/en-in/features/azure-portal/)
- HTML
- CSS
- Bootstrap
- JavaScript
